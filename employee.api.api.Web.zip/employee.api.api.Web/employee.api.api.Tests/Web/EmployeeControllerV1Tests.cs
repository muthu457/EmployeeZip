﻿using employee.api.api.Domain.EmployeeOperations.Interfaces;
using employee.api.api.Web;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using employee.api.api.Tests.Data;
using Xunit;
using System.Threading.Tasks;
using System.Net;
using employee.api.api.Domain.EmployeeOperations.Models;
using Moq;

namespace employee.api.api.Tests.Web
{
    public class EmployeeControllerV1Tests : IDisposable
    {
        protected TestServer Server;
        protected HttpClient Client;
        private const string RequestUri = "/v1/api/Employee";
        public Mock<IEmployeeRepository> mock = new Mock<IEmployeeRepository>();
        public EmployeeControllerV1Tests()
        {
            var builder = new WebHostBuilder().ConfigureAppConfiguration((config) =>
            {
                config.AddJsonFile("appsetting.json", optional: true, reloadOnChange: false);
            }).ConfigureServices(services=>
            {
                services.AddScoped<IEmployeeRepository, TestEmployeeRepository>();
            })
            .UseStartup<Startup>();
            Server = new TestServer(builder);
            Client = Server.CreateClient();
            
        }
        public void Dispose()
        {
            Server?.Dispose();
            Client?.Dispose();
        }

        [Fact]
        public async Task GetAllEmployeeList_Success()
        {
            var response = await Client.GetAsync(RequestUri);
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            Dispose();
        }

        [Fact]
        public async Task AddEmployee_Success_InputData()
        {
            var employee = new Employee { AddressLine = "Shollinganalur", City = "Chennai", Email = "123@gmail.com", EmployeeType = "Permanent", FirstName = "MuthuKumaran", LastName = "Veerappan" };
            var newValString = JsonConvert.SerializeObject(employee);
            var postedContent = new StringContent(newValString, Encoding.UTF8, "application/json");
            var response = await Client.PostAsync(RequestUri, postedContent);
            var value = response.Content.ReadAsStringAsync().Result;
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            Dispose();
        }

        [Fact]
        public async Task AddEmployee_Failure_InputData()
        {
            var employee = new Employee { EmployeeId = 1, AddressLine = "Shollinganalur", City = "Chennai", Email = "123@gmail.com", EmployeeType = "Permanent", FirstName = "MuthuKumaran", LastName = "Ran" };
            var newValString = JsonConvert.SerializeObject(employee);
            var postedContent = new StringContent(newValString, Encoding.UTF8, "application/json");
            var response = await Client.PostAsync(RequestUri, postedContent);
            var value = response.Content.ReadAsStringAsync().Result;
            Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
            Dispose();
        }

        [Fact]
        public async Task GetEmployee_Success_InputData()
        {
            var response = await Client.GetAsync(RequestUri + "/1");
            Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
            Dispose();
        }

        [Fact]
        public async Task GetEmployee_Failure_InputData()
        {
            var response = await Client.GetAsync(RequestUri + "/0");
            Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
            Dispose();
        }

        [Fact]
        public async Task DeleteEmployee_Failure_InputData()
        {
            var response = await Client.DeleteAsync(RequestUri + "/0");
            Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
            Dispose();
        }


        [Fact]
        public async Task DeleteEmployee_Success_InputData()
        {
            var response = await Client.DeleteAsync(RequestUri + "/1");
            Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
            Dispose();
        }
    }
}
